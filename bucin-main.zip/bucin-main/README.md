# Bucin Code


💐 Cara anak Ti deketin CEWE :)


This project utilizes the following programming languages and technologies:
- HTML
- CSS
- SCSS (Sass)
- JavaScript

## 🖇 Installation
# Using Git

```console
farid@Ubuntu~ $ pip3 install git
farid@Ubuntu~ $ git clone https://github.com/tiunusia/bucin.git
```

# Download ZIP

<p align="left"><img src="ss.png" alt="ICON" width="500" height="300"/></p>
